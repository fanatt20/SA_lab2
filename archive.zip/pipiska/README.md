# SA_lab2
Theory for solving SLAEs using method of random search (one of directed methods - method of best probe):
http://bigor.bmstu.ru/?cnt/?doc=MO/ch0801.mod/?cou=MO/base.cou
How to get a mathematical optimisation task from SLAE:
https://ru.wikipedia.org/wiki/%D0%93%D1%80%D0%B0%D0%B4%D0%B8%D0%B5%D0%BD%D1%82%D0%BD%D1%8B%D0%B5_%D0%BC%D0%B5%D1%82%D0%BE%D0%B4%D1%8B
